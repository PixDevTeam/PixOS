cd /Users/tristan/Desktop/Stuff/PixOS/1.0/src/
nasm kernel.asm -f bin -o kernel.bin
cd img
cp pixos.flp pixos.dmg
echo "[okay] Copied floppy image"
dd conv=notrunc if=/Users/tristan/Desktop/Stuff/PixOS/mikeos-4.5/source/bootload/bootload.bin of=/Users/tristan/Desktop/Stuff/PixOS/1.0/src/img/pixos.dmg
echo "[okay] Added bootloader to image"
rm -f pixos.iso
hdiutil attach pixos.dmg
read -p "Press [Enter] key after putting kernel on disk…"
read -p "Press [Enter] key after ejecting disk…"
echo "[okay] Added kernel to image"
cd ..
mkisofs -quiet -V 'PIXOS' -input-charset iso8859-1 -o img/pixos.iso -b pixos.dmg img/
echo "[done] Build completed"
