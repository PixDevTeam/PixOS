cd /Users/tristan/Desktop/Stuff/PixOS/1.0-1.4/app/API\ 1.5
nasm -o test.bin prog.asm